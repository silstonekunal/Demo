Readme: https://github.com/alexa/alexa-smarthome/wiki/Sample-Messages
