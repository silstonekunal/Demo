# Lambda Functions for Sample Smart Home Backend

### lambda_api
This is written in python and functions as the device cloud for an Alexa Smart Home Skill.

### lambda_smarthome
The Smart Home Skill Lambda that routes directives from Alexa to the customer endpoint. 

