# Build an Alexa Smart Home Skill and Backend
These instructions build a Sample Alexa Smart Home skill and backend using Cloud Formation using the API Gateway as an access layer to AWS IoT Things that represent the state of customer endpoints.


To begin, start with [Step 0: Set Up the Required Accounts](000-setup-requirements.md) 

