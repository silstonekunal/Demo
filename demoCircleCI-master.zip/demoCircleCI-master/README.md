# demoCircleCI

Project to demo CI/CD with Circle CI and also display various badges like build passing or failing and code coverage etc

Some Additional changes, New

[![HitCount](http://hits.dwyl.io/AadiMehta/demoCircleCI.svg)](http://hits.dwyl.io/AadiMehta/demoCircleCI)
