# demoSoapToRest
Simple django server which creates a REST wrapper around SOAP services. The project showcases an easy way to integrate various SOAP API with new modern REST API services
